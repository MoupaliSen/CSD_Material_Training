package com.cognizant.springlearn.bean.springlearn3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springlearn3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
