package com.cognizant.springlearn.bean.springlearn3.Dao;
import org.springframework.stereotype.Component;
@Component
public class EmployeeDao {

 EmployeeDao() {
        System.out.println("EmployeeDao constructor called");
    }


}
