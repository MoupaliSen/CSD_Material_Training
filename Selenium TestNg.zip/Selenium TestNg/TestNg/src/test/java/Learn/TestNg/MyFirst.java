package Learn.TestNg;

import org.testng.annotations.Test;

public class MyFirst {
	@Test
	void test1()
	{
		System.out.println("testing 1");
	}
	
	@Test
	void test2()
	{
		System.out.println("testing 2");

	}
	
	@Test
	void test3()
	{
		System.out.println("testing 3");

	}
  
}
