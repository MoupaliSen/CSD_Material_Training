package Learn.TestNg.DataProvider;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
//import org.testng.annotations.DataProvider;


//import dev.failsafe.internal.util.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DataProvider {
	WebDriver driver;
	@BeforeClass
	void setup()
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();

	}
	@Test(dataProvider = "dp") //dataProvider is a parameter
	void testlogin(String email,String password)
	{
		driver.get("https://demo.nopcommerce.com/login");
		driver.manage().window().maximize();
		driver.findElement(By.id("Email")).sendKeys(email);
		driver.findElement(By.id("Password")).sendKeys(pwd);
		driver.findElement(By.xpath("//button[normalize-space()='Log in']")).click();

		String exp_title = "nopCommerce demo store";
		String act_title = driver.getTitle();

		Assert.assertEquals(exp_title, act_title);

		
		
	}
	
	@AfterClass
	void tearDown()
	{
		driver.close();

		
	}
	
	 @DataProvider(name ="dp",indices = {0,1,4}) // DataProvider is a annotations
	String[][] loginData()
	{
		String data[][] = {
				{"abc@gamil.com","test123"},
				{"abcd@gamil.com","test1234"},

				{"abcde@gamil.com","test1235"},

				{"abcdef@gamil.com","test1236"},

				{"abcdefg@gamil.com","test1237"}

		        };
		return data;
	}

}
