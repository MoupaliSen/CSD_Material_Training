package com.oops.methodoverloading;

public class TestAdder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Adder.add(10, 15));
		System.out.println(Adder.add(10, 15, 20));
		System.out.println(Adder.add(12.5f,10.5f));

	}

}
