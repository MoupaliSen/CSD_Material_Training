package com.oops.methodoverloading;

public class Adder {
	static int add(int a,int b)
	{
		return a+b;
	}
	
	static int add(int a,int b,int c)
	{
		return a+b+c;
	}
	static float add(float a,float b)
	{
		return a+b;
	}



}
