package com.oops.inheritance;

public class Father {
	int assest =1000;
	void education()
	{
		System.out.println("Father is a doctor");
	}
	

}
