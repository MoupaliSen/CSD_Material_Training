package com.oops.inheritance;

public class GrandSon extends Son {
	int standard = 5;
	void education()
	{
		System.out.println("Grandchild is a student");
	}

}
