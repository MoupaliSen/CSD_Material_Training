package com.oops.inheritance;

public class Son extends Father{
	int age =35;
	
	void education()
	{
		System.out.println("Son is an Engineer");

	}

}
