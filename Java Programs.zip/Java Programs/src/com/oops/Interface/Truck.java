package com.oops.Interface;

public class Truck implements Vehicle {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Truck is running");
		
	}

	@Override
	public float amt() {
		// TODO Auto-generated method stub
		return 2.5f;
	}
	

}
