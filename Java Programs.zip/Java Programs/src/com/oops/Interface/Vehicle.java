package com.oops.Interface;

public interface Vehicle {
	void run();
	float amt();
	
	static int square(int x)
	{
		return x*x;
	}

}
