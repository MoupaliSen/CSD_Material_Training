package com.oops.Interface;

 class Car implements Vehicle{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Car is running");
		
	}

	@Override
	public float amt() {
		// TODO Auto-generated method stub
		return 13.5f;
	}
	
	
	

}
