package com.oops.methodoverriding;

public class Bike extends Vechicle{
	void run(){
		System.out.println("Bike is running safe");
		}


}
