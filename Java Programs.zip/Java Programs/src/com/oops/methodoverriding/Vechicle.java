package com.oops.methodoverriding;

public class Vechicle {
	void run(){
		System.out.println("Vehicle is running");
	}

}
