package com.oops.Abstraction;

abstract  class Bike {
	abstract void run();

}
