package com.oops.Abstraction;

public class Honda extends Bike{
	
	void run() {
		// TODO Auto-generated method stub
		System.out.println("Honda Bike is black");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bike b = new Honda();
		b.run();

	}

	

}
