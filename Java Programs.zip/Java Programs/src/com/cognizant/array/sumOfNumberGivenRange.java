package com.cognizant.array;

public class sumOfNumberGivenRange {
	public static void main(String[] args)
	{
		int num1=12;
		int num2=15;
		int sum =0;
		
		for(int i=num1;i<=num2;i++)
		{
			sum =sum+i;
		}
		System.out.println(sum);
	}

}
