package com.cognizant.multipleInheritance;

public interface ClassB {
	void eat();

}
