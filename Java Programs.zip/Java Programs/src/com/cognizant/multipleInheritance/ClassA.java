package com.cognizant.multipleInheritance;

public interface ClassA {
	  void run();
}
