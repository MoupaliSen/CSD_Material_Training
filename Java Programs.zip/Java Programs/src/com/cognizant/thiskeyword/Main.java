package com.cognizant.thiskeyword;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s = new Student(1, "Abc");
		s.display();
		

	}

}
