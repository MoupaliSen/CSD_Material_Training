package com.cognizant.superKeyword;

public class Animal {
	String color ="White";

}
