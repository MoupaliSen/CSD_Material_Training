package com.cognizant.superKeyword;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d = new Dog();
		d.printColour();

	}

}
